package vamc.linda.loma.foundation.service;


public interface Service {

	public boolean isAlive();
	
}
