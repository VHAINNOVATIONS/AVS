package vamc.linda.loma.kaajee.jboss.model.json;

public class InstitutionJson {

	private String divisionName;
	private String stationNumber;
	
	public String getDivisionName() {
		return divisionName;
	}
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	public String getStationNumber() {
		return stationNumber;
	}
	public void setStationNumber(String stationNumber) {
		this.stationNumber = stationNumber;
	}	
}
