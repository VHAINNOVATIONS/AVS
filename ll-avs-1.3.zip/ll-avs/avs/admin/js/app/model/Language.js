Ext.define('LLVA.AVS.Admin.model.Language', {
	extend: 'Ext.data.Model',

	fields: [		
        'abbreviation',
        'name'
	]
});
