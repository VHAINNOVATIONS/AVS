Ext.define('LLVA.AVS.Admin.model.Label', {
	extend: 'Ext.data.Model',

	fields: [		
		'language',
        'stationNo',
        'name',
		'value'
	]
});
