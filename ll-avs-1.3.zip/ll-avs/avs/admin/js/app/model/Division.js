Ext.define('LLVA.AVS.Admin.model.Division', {
	extend: 'Ext.data.Model',

	fields: [		
        'insitutionId',
        'facilityNo',
        'name',
        'isDefault'
	]
});
