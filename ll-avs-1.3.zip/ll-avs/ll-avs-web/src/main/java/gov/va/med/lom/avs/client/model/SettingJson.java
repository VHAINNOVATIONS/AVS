package gov.va.med.lom.avs.client.model;

public class SettingJson {

	private String setting;
	private String name;
	private String value;
	
  public String getSetting() {
    return setting;
  }
  public void setSetting(String setting) {
    this.setting = setting;
  }
  public String getValue() {
    return value;
  }
  public void setValue(String value) {
    this.value = value;
  }
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }
  
}
