package gov.va.med.lom.avs.enumeration;

public enum DisclaimerTypeEnum {

	facility,
	clinic,
	provider;

}

