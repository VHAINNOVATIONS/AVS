package gov.va.med.lom.avs.enumeration;

public enum SortDirectionEnum {

	ASC,
	DESC;

	private SortDirectionEnum() {}
}
