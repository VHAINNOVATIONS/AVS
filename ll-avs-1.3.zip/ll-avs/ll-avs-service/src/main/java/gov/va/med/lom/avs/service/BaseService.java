package gov.va.med.lom.avs.service;

abstract public interface BaseService {

	public boolean isAlive();

}
