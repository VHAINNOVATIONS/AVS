package gov.va.med.lom.avs.enumeration;

public enum SortEnum {

	id,
	type,
	source,
	translation,
	name,
	location;

	private SortEnum() {}
}

