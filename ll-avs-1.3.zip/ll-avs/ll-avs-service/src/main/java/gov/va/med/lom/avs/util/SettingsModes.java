package gov.va.med.lom.avs.util;

public enum SettingsModes {
	NONE,
	PROVIDER,
	CLINIC,
	FACILITY
}
