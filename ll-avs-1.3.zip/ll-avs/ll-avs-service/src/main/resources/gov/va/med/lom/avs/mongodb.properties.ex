mongodb.server=localhost
mongodb.db=avs