db.server=localhost
db.port=1433
db.name=Clinical
db.username=xx
db.password=xx
db.drivertype=jtds
db.database=sqlserver
db.driver=net.sourceforge.jtds.jdbc.Driver