vista.vistaServer=
vista.vistaPort=
vista.vistaAV=
vista.minPoolSize=
vista.reapDelay=
vista.inactiveTimeout=