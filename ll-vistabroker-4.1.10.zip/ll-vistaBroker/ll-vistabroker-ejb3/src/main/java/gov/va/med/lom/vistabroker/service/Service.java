package gov.va.med.lom.vistabroker.service;

public interface Service {
	
	public boolean isAlive();
}
