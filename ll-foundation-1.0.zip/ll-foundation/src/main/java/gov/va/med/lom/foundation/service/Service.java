package gov.va.med.lom.foundation.service;


public interface Service {

	public boolean isAlive();
	
}
