package gov.va.med.lom.javaBroker.rpc.patient.models;

public class UnsignedNotesByServiceReport {

  
}
