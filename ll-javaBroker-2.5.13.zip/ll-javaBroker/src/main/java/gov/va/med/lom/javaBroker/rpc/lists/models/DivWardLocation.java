package gov.va.med.lom.javaBroker.rpc.lists.models;

public class DivWardLocation {

	private String ien;
	private String division;
	private String name;
	
	
	public String getDivision() {
		return division;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public String getIen() {
		return ien;
	}
	public void setIen(String ien) {
		this.ien = ien;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
